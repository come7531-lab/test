---
name: mind-story
description: Make a hand-drawn pastel crayon video (손그림 크레파스 마음 영상) that explains a book's, teacher's or script's message in full-frame drawn scenes with hand-written Korean words, diagram arrows, zoom-in/zoom-out camera, bottom subtitles, a soft felt-piano score, far birds and soft wind only on transitions — exactly the approved "레스터 레븐슨의 지혜" style. Any length (follows the script or the narration), script-first mode, narration (voice file) mode, 16:9 or vertical 9:16 Shorts/Reels, and a volume table (bigger number = louder) on every delivery. Use when the user asks for "크레파스 손그림 영상", "마음 영상", "지혜 영상", "그 스타일로 영상", a new episode of this series, sends a script or a voice file for it, or invokes /mind-story.
---

# Mind Story (크레파스 마음 영상)

Makes a new episode of the user's series in the **locked style** of the approved first film.
`template/` is that exact film, working end to end. The story, length and format change; the look and the
sound do not. Read `references/style-guide.md` before writing anything: palette, drawing toolkit,
layout rules, 9:16 rules, and the locked sound.

Talk to the user in Korean, simply. They are a creator, not a developer.

## 0. Decide the mode from the request

| The user gives… | Do |
|---|---|
| only a topic or book | **Script-first.** Write the scene table (below), show it, wait for OK or edits, then make the video. |
| a script (from you, Claude, GPT…) | Use it as is. Split it into scenes, one sentence = one scene. Show the scene table briefly, then make the video, unless they asked to check it first. |
| a voice file + its script | **Narration mode** (section 3b). The film length = the voice length. |
| a voice file without a script | Ask for the script text (one sentence per line). Audio cannot be transcribed here. |
| a length ("1분", "40초") | Fit the content to that length. Pick the scene count ≈ length ÷ 3.3 s and shorten or merge sentences. Never crop a finished film. |
| no length | The length follows the script: one scene per sentence. |
| 쇼츠 / 릴스 / 틱톡 / 세로 | Vertical **9:16**: re-stage every scene for 1080×1920 (style guide §9:16). Say so. |

**Scene table** (show this to the user):

| # | 자막 (한 문장) | 손글씨 키워드 | 그림 / 다이어그램 | 카메라 | 길이 |

- **Length without narration:** a subtitle up to about 22 characters gets 1 bar (3.3 s); a longer one gets 2 bars.
- **Proven arc for short films:** problem (person + burden) → mechanism (A→B→C cycle diagram) → turn (the practice, shown) → insight (zoom inside, X over the wrong answer) → principle (a simple graph) → rest (calm landscape + title + "○○○의 지혜").
- **Longer films:** repeat the middle beats with new pictures. Keep one idea per scene, and keep returning to the same little person.
- Never invent quotes. Say the ideas plainly. If unsure of a book's Korean title, write it neutrally and say so.

## 1. Scaffold
```bash
sh .claude/skills/mind-story/scripts/new-film.sh <kebab-case-topic>
```
- If the skill came from an uploaded zip, the path is the skill's own folder: use the "Base directory for this skill" shown on load + `/scripts/new-film.sh`.
- Create the project in the working directory unless the user names a place.
- The script writes `out/chrome.sh` (Chromium with `--no-sandbox`). Run every later command as `cd <dir> && CHROME_PATH=$PWD/out/chrome.sh node engine/render.js …`.

## 2. Edit only the per-film parts
- **score.js:**
  - `SCENES` (key, sub, bars)
  - `ev` (moments things pop or draw, via `at(sceneIndex, beats)`)
  - `sfx` (which moments get a whoosh, a drift or birds)
  - `FORMAT` for 9:16
  - Harmony, melody, tempo and accompaniment are locked. They loop to any length and end on Fmaj7·Gsus → Cadd9.
- **film.js:** only the block marked `PER-FILM PART`, i.e. the `bgs` backgrounds, one `sceneX(ctx, t)` per scene and the `SCENES` list (same keys and order as score.js).
  - Read times from `S.S[key]` and `ev`, never hard-coded seconds.
  - Reuse the toolkit: `crayonFill crayonLine shape blobPts rrPts curve arrow word loop sparkle cloud birdV person hairCap cam vgrad hillPts FULL pr sm`.
  - **Camera:** every new scene uses `camMove(ctx, t, key, recipe, { focus, to })` with one of the six approved recipes (`push pullPan follow reveal dive pullBack`) and the mixing rules in the style guide. Show the recipe in the scene table's 카메라 column.
  - Do not touch the toolkit, palette, fonts, subtitles or the cross-fade runner.
- **song.js:** do not touch the instruments. Change sound only through the `LEVEL_DB` knobs (section 5).

## 3a. Without narration
`node song.js` makes the music and prints the sound table.

## 3b. Narration mode
1. Save the user's script as `script.txt`, one sentence per line, in the same order as `SCENES`.
2. Run `node tools/align.js <voice file> script.txt`.
   - It finds the pauses in the voice and writes `voice-timing.js` (the scene and subtitle times).
   - It copies the voice into the project and prints a table: # · 시작 · 끝 · 문장.
3. Show that table. Rows marked "확인" were joined or split by guess; check them in a still. A wrong row can be fixed by editing the numbers in `voice-timing.js`.
4. `SCENES` must have exactly as many scenes as sentences.
5. `node song.js` loads the voice and dips the music under it (`DUCK`). The table gains a 내레이션 row.
   - To remove the narration, put back the template's `voice-timing.js` (`const VT = null`).

## 4. Review, then render
```bash
node engine/render.js stills <the middle of each scene>   # → out/stills/
```
Look at every still against the layout rules; fix and re-render until clean. Then:
```bash
node engine/render.js video     # minutes: run in the background
node engine/render.js mux       # → out/<dir>.mp4
node engine/render.js check     # contact sheet + loudness
```

## 5. Sound as VOLUME numbers (every delivery)
The user does not want dB. Talk only in **볼륨 numbers**: bigger = louder, like a phone. The dB maths stays with you.
- **Volume** = 100 + the sound's measured average level in dB. 1 step = 1 dB.
  - 3 steps = 살짝 · 6 = 절반 느낌 · 10 = 확 작게.
  - The total uses LUFS: total volume = 100 + LUFS, so YouTube's normal level (−14 LUFS) = **86**.
- **Always** paste the volume table that `node song.js` prints (also saved in `out/sound-levels.md`).
  - It shows each sound's volume with a bar, the total, and a "바뀐 것" column (before → after, from `out/sound-levels.json`).
  - It also shows the YouTube reference lines.
  - Never show dB to the user unless they ask.
- **Mapping requests to the dB knobs** in `song.js` `LEVEL_DB`. The measured volume moves exactly with the knob.

  | 사용자가 하는 말 | knob |
  |---|---|
  | 피아노 반주 | `piano` |
  | 멜로디 | `lead` |
  | 피아노 전체 | both `piano` and `lead` |
  | 잔향 / 울림 | `verb` |
  | 새소리 | `birds` |
  | 바람 / 효과음 | `fx` |
  | 내레이션 / 목소리 | `voice` |
  | 음악이 목소리 아래로 깔리는 정도 | `DUCK` (0–0.9) |

  - "X 3 낮춰 / 올려" → knob −3 / +3.
  - "X 62로" → knob += 62 − current volume.
  - "X를 Y랑 같게" → knob += vol(Y) − vol(X).
  - "50%로" ≈ −6 · "35%" ≈ −9 · "70%" ≈ −3.
  - "전체 80으로" / "전체 6 올려" → `LUFS=<target − 100> node song.js`. This keeps the balance and moves everything together; `LUFS` stays set for later runs in this film.
- **Sound-only change:** edit `song.js`, run `node song.js`, then `node engine/render.js mux`. This re-uses `out/video.mp4`; never re-render the picture for a sound change. Reply with the table: its "바뀐 것" column shows before → after.
- If a new default should stick for future films, also update the knob in the skill's `template/song.js` and the style guide, and tell the user to re-upload the skill zip.

## 6. Deliver
- Send `out/<dir>.mp4`.
- List the scenes with their subtitles.
- Paste the volume table.
- Say the audio was checked by measurement, not by ear.
- Offer: 세로(9:16) 버전, 길이 조정, 내레이션 추가.
- Commit or push only if the session's instructions say so.
